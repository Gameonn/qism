<?php
require_once('../phpInclude/db_connection.php');
require_once('../classes/AllClasses.php');

var_dump($conn);
?>